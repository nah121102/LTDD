import 'dart:core';
import 'dienthoai.dart'; // Import lớp DienThoai nếu tách file

class HoaDon {
  // Thuộc tính private
  String _maHoaDon;
  DateTime _ngayBan;
  DienThoai _dienThoai;
  int _soLuongMua;
  double _giaBanThucTe;
  String _tenKhachHang;
  String _soDienThoaiKhach;

  // Constructor đầy đủ tham số với validation
  HoaDon(
    this._maHoaDon,
    this._ngayBan,
    this._dienThoai,
    this._soLuongMua,
    this._giaBanThucTe,
    this._tenKhachHang,
    this._soDienThoaiKhach,
  ) {
    _validateMaHoaDon(_maHoaDon);
    _validateNgayBan(_ngayBan);
    _validateSoLuongMua(_soLuongMua, _dienThoai.soLuongTon);
    _validateGiaBanThucTe(_giaBanThucTe);
    _validateThongTinKhach(_tenKhachHang, _soDienThoaiKhach);
  }

  // Getter và Setter với validation
  String get maHoaDon => _maHoaDon;
  set maHoaDon(String value) {
    _validateMaHoaDon(value);
    _maHoaDon = value;
  }

  DateTime get ngayBan => _ngayBan;
  set ngayBan(DateTime value) {
    _validateNgayBan(value);
    _ngayBan = value;
  }

  DienThoai get dienThoai => _dienThoai;

  int get soLuongMua => _soLuongMua;
  set soLuongMua(int value) {
    _validateSoLuongMua(value, _dienThoai.soLuongTon);
    _soLuongMua = value;
  }

  double get giaBanThucTe => _giaBanThucTe;
  set giaBanThucTe(double value) {
    _validateGiaBanThucTe(value);
    _giaBanThucTe = value;
  }

  String get tenKhachHang => _tenKhachHang;
  set tenKhachHang(String value) {
    _validateThongTinKhach(value, _soDienThoaiKhach);
    _tenKhachHang = value;
  }

  String get soDienThoaiKhach => _soDienThoaiKhach;
  set soDienThoaiKhach(String value) {
    _validateThongTinKhach(_tenKhachHang, value);
    _soDienThoaiKhach = value;
  }

  // Phương thức tính tổng tiền
  double tinhTongTien() => _giaBanThucTe * _soLuongMua;

  // Phương thức tính lợi nhuận thực tế
  double tinhLoiNhuanThucTe() {
    double loiNhuanTrenSanPham = _giaBanThucTe - _dienThoai.giaNhap;
    return loiNhuanTrenSanPham * _soLuongMua;
  }

  // Phương thức hiển thị thông tin hóa đơn
  void hienThiThongTin() {
    print('''
    Mã hóa đơn: $_maHoaDon
    Ngày bán: $_ngayBan
    Tên điện thoại: ${_dienThoai.tenDienThoai}
    Số lượng mua: $_soLuongMua
    Giá bán thực tế: $_giaBanThucTe
    Tên khách hàng: $_tenKhachHang
    Số điện thoại khách hàng: $_soDienThoaiKhach
    Tổng tiền: ${tinhTongTien()}
    Lợi nhuận thực tế: ${tinhLoiNhuanThucTe()}
    ''');
  }

  // Phương thức kiểm tra tính hợp lệ của mã hóa đơn
  void _validateMaHoaDon(String value) {
    if (value.isEmpty || !RegExp(r'^HD-\d{3}$').hasMatch(value)) {
      throw Exception('Mã hóa đơn không hợp lệ. Định dạng: "HD-XXX"');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của ngày bán
  void _validateNgayBan(DateTime value) {
    if (value.isAfter(DateTime.now())) {
      throw Exception('Ngày bán không được sau ngày hiện tại.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của số lượng mua
  void _validateSoLuongMua(int soLuong, int tonKho) {
    if (soLuong <= 0) {
      throw Exception('Số lượng mua phải lớn hơn 0.');
    }
    if (soLuong > tonKho) {
      throw Exception('Số lượng mua không được vượt quá tồn kho.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của giá bán thực tế
  void _validateGiaBanThucTe(double value) {
    if (value <= 0) {
      throw Exception('Giá bán thực tế phải lớn hơn 0.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của thông tin khách hàng
  void _validateThongTinKhach(String tenKhach, String soDienThoai) {
    if (tenKhach.isEmpty) {
      throw Exception('Tên khách hàng không được để trống.');
    }
    if (!RegExp(r'^\d{10,11}$').hasMatch(soDienThoai)) {
      throw Exception(
          'Số điện thoại khách không hợp lệ. Phải có 10-11 chữ số.');
    }
  }
}
