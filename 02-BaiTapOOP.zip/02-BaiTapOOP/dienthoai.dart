class DienThoai {
  // Thuộc tính private
  String _maDienThoai;
  String _tenDienThoai;
  String _hangSanXuat;
  double _giaNhap;
  double _giaBan;
  int _soLuongTon;
  bool _trangThai;

  // Constructor đầy đủ tham số với validation
  DienThoai(
    this._maDienThoai,
    this._tenDienThoai,
    this._hangSanXuat,
    this._giaNhap,
    this._giaBan,
    this._soLuongTon,
    this._trangThai,
  ) {
    _validateMaDienThoai(_maDienThoai);
    _validateTenDienThoai(_tenDienThoai);
    _validateHangSanXuat(_hangSanXuat);
    _validateGia(_giaNhap, _giaBan);
    _validateSoLuongTon(_soLuongTon);
  }

  // Getter và Setter với validation
  String get maDienThoai => _maDienThoai;
  set maDienThoai(String value) {
    _validateMaDienThoai(value);
    _maDienThoai = value;
  }

  String get tenDienThoai => _tenDienThoai;
  set tenDienThoai(String value) {
    _validateTenDienThoai(value);
    _tenDienThoai = value;
  }

  String get hangSanXuat => _hangSanXuat;
  set hangSanXuat(String value) {
    _validateHangSanXuat(value);
    _hangSanXuat = value;
  }

  double get giaNhap => _giaNhap;
  set giaNhap(double value) {
    _validateGia(value, _giaBan);
    _giaNhap = value;
  }

  double get giaBan => _giaBan;
  set giaBan(double value) {
    _validateGia(_giaNhap, value);
    _giaBan = value;
  }

  int get soLuongTon => _soLuongTon;
  set soLuongTon(int value) {
    _validateSoLuongTon(value);
    _soLuongTon = value;
  }

  bool get trangThai => _trangThai;
  set trangThai(bool value) {
    _trangThai = value;
  }

  // Phương thức tính lợi nhuận dự kiến
  double tinhLoiNhuanDuKien() => _giaBan - _giaNhap;

  // Phương thức kiểm tra có thể bán không
  bool coTheBan() => _soLuongTon > 0 && _trangThai;

  // Phương thức hiển thị thông tin
  void hienThiThongTin() {
    print('''
    Mã điện thoại: $_maDienThoai
    Tên điện thoại: $_tenDienThoai
    Hãng sản xuất: $_hangSanXuat
    Giá nhập: $_giaNhap
    Giá bán: $_giaBan
    Số lượng tồn: $_soLuongTon
    Trạng thái: ${_trangThai ? 'Còn kinh doanh' : 'Ngừng kinh doanh'}
    ''');
  }

  // Phương thức kiểm tra tính hợp lệ của mã điện thoại
  void _validateMaDienThoai(String value) {
    if (value.isEmpty || !RegExp(r'^DT-\d{3}$').hasMatch(value)) {
      throw Exception('Mã điện thoại không hợp lệ. Định dạng: "DT-XXX"');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của tên điện thoại
  void _validateTenDienThoai(String value) {
    if (value.isEmpty) {
      throw Exception('Tên điện thoại không được để trống.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của hãng sản xuất
  void _validateHangSanXuat(String value) {
    if (value.isEmpty) {
      throw Exception('Hãng sản xuất không được để trống.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của giá
  void _validateGia(double giaNhap, double giaBan) {
    if (giaNhap <= 0) {
      throw Exception('Giá nhập phải lớn hơn 0.');
    }
    if (giaBan <= 0 || giaBan <= giaNhap) {
      throw Exception('Giá bán phải lớn hơn giá nhập và lớn hơn 0.');
    }
  }

  // Phương thức kiểm tra tính hợp lệ của số lượng tồn
  void _validateSoLuongTon(int value) {
    if (value < 0) {
      throw Exception('Số lượng tồn không được nhỏ hơn 0.');
    }
  }
}
