import 'dienthoai.dart';
import 'hoadon.dart';

class CuaHang {
  // Thuộc tính private
  String _tenCuaHang;
  String _diaChi;
  List<DienThoai> _danhSachDienThoai = [];
  List<HoaDon> _danhSachHoaDon = [];

  // Constructor với tên và địa chỉ
  CuaHang(this._tenCuaHang, this._diaChi);

  // Getter và Setter cho tên và địa chỉ
  String get tenCuaHang => _tenCuaHang;
  set tenCuaHang(String value) {
    if (value.isEmpty) throw Exception('Tên cửa hàng không được để trống');
    _tenCuaHang = value;
  }

  String get diaChi => _diaChi;
  set diaChi(String value) {
    if (value.isEmpty) throw Exception('Địa chỉ không được để trống');
    _diaChi = value;
  }

  // Phương thức quản lý điện thoại

  // Thêm điện thoại mới
  void themDienThoai(DienThoai dienThoai) {
    if (_danhSachDienThoai
        .any((dt) => dt.maDienThoai == dienThoai.maDienThoai)) {
      throw Exception('Mã điện thoại đã tồn tại');
    }
    _danhSachDienThoai.add(dienThoai);
  }

  // Cập nhật thông tin điện thoại
  void capNhatDienThoai(String maDienThoai, DienThoai dienThoaiMoi) {
    var index =
        _danhSachDienThoai.indexWhere((dt) => dt.maDienThoai == maDienThoai);
    if (index == -1) throw Exception('Không tìm thấy điện thoại');
    _danhSachDienThoai[index] = dienThoaiMoi;
  }

  // Ngừng kinh doanh điện thoại
  void ngungKinhDoanhDienThoai(String maDienThoai) {
    var dienThoai = _danhSachDienThoai.firstWhere(
        (dt) => dt.maDienThoai == maDienThoai,
        orElse: () => throw Exception('Không tìm thấy điện thoại'));
    dienThoai.trangThai = false;
  }

  // Tìm kiếm điện thoại theo mã, tên hoặc hãng
  DienThoai? timKiemDienThoai(String keyword) {
    try {
      return _danhSachDienThoai.firstWhere(
          (dt) =>
              dt.maDienThoai.contains(keyword) ||
              dt.tenDienThoai.contains(keyword) ||
              dt.hangSanXuat.contains(keyword),
          orElse: () => throw Exception(
              'Không tìm thấy điện thoại với từ khóa: $keyword'));
    } catch (e) {
      print(e);
      return null; // Trả về null khi không tìm thấy điện thoại
    }
  }

  // Hiển thị danh sách điện thoại
  void hienThiDanhSachDienThoai() {
    if (_danhSachDienThoai.isEmpty) {
      print('Không có điện thoại nào trong danh sách.');
      return;
    }
    print('Danh sách điện thoại:');
    for (var dt in _danhSachDienThoai) {
      dt.hienThiThongTin();
    }
  }

  // Phương thức quản lý hóa đơn

  // Tạo hóa đơn mới
  void taoHoaDon(HoaDon hoaDon) {
    var dienThoai = hoaDon.dienThoai;
    if (hoaDon.soLuongMua > dienThoai.soLuongTon) {
      throw Exception('Số lượng mua vượt quá tồn kho');
    }
    // Cập nhật tồn kho
    dienThoai.soLuongTon -= hoaDon.soLuongMua;
    _danhSachHoaDon.add(hoaDon);
  }

  // Tìm kiếm hóa đơn theo mã, ngày hoặc khách hàng
  List<HoaDon> timKiemHoaDon(String keyword) {
    return _danhSachHoaDon.where((hd) {
      return hd.maHoaDon.contains(keyword) ||
          hd.tenKhachHang.contains(keyword) ||
          hd.soDienThoaiKhach.contains(keyword);
    }).toList();
  }

  // Hiển thị danh sách hóa đơn
  void hienThiDanhSachHoaDon() {
    if (_danhSachHoaDon.isEmpty) {
      print('Không có hóa đơn nào trong danh sách.');
      return;
    }
    print('Danh sách hóa đơn:');
    for (var hd in _danhSachHoaDon) {
      hd.hienThiThongTin();
    }
  }

  // Phương thức thống kê

  // Tính tổng doanh thu theo khoảng thời gian
  double tinhTongDoanhThu(DateTime from, DateTime to) {
    return _danhSachHoaDon
        .where((hd) =>
            hd.ngayBan.isAfter(from.subtract(Duration(days: 1))) &&
            hd.ngayBan.isBefore(to.add(Duration(days: 1))))
        .fold(0.0, (sum, hd) => sum + hd.tinhTongTien());
  }

  // Tính tổng lợi nhuận theo khoảng thời gian
  double tinhTongLoiNhuan(DateTime from, DateTime to) {
    return _danhSachHoaDon
        .where((hd) =>
            hd.ngayBan.isAfter(from.subtract(Duration(days: 1))) &&
            hd.ngayBan.isBefore(to.add(Duration(days: 1))))
        .fold(0.0, (sum, hd) => sum + hd.tinhLoiNhuanThucTe());
  }

  // Thống kê top điện thoại bán chạy
  List<DienThoai> thongKeTopBanChay(int topN) {
    var banChay = <String, int>{};
    for (var hoaDon in _danhSachHoaDon) {
      var maDienThoai = hoaDon.dienThoai.maDienThoai;
      banChay[maDienThoai] = (banChay[maDienThoai] ?? 0) + hoaDon.soLuongMua;
    }
    var sorted = banChay.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted
        .take(topN)
        .map((entry) =>
            _danhSachDienThoai.firstWhere((dt) => dt.maDienThoai == entry.key))
        .toList();
  }

  // Thống kê tồn kho
  void thongKeTonKho() {
    print('Báo cáo tồn kho:');
    for (var dienThoai in _danhSachDienThoai) {
      print(
          'Mã: ${dienThoai.maDienThoai}, Tên: ${dienThoai.tenDienThoai}, Tồn kho: ${dienThoai.soLuongTon}');
    }
  }
}
