import 'dienthoai.dart';
import 'hoadon.dart';
import 'cuahang.dart';

void main() {
  try {
    // Tạo cửa hàng
    var cuaHang = CuaHang('Cửa hàng Điện Thoại XYZ', 'Số 123, Đường ABC');

    // Thêm điện thoại mới
    var dienThoai1 =
        DienThoai('DT-001', 'iPhone 14', 'Apple', 10000, 15000, 100, true);
    cuaHang.themDienThoai(dienThoai1);

    var dienThoai2 = DienThoai(
        'DT-002', 'Samsung Galaxy S21', 'Samsung', 12000, 17000, 50, true);
    cuaHang.themDienThoai(dienThoai2);

    var dienThoai3 =
        DienThoai('DT-003', 'Xiaomi Mi 11', 'Xiaomi', 8000, 12000, 200, true);
    cuaHang.themDienThoai(dienThoai3);

    var dienThoai4 =
        DienThoai('DT-004', 'Oppo Find X3', 'Oppo', 9000, 14000, 150, true);
    cuaHang.themDienThoai(dienThoai4);

    // Hiển thị danh sách điện thoại
    print('Danh sách điện thoại sau khi thêm:');
    cuaHang.hienThiDanhSachDienThoai();

    // Tạo hóa đơn
    var hoaDon1 = HoaDon('HD-001', DateTime.now(), dienThoai1, 2, 16000,
        'Nguyễn Văn A', '0123456789');
    cuaHang.taoHoaDon(hoaDon1);

    var hoaDon2 = HoaDon('HD-002', DateTime.now(), dienThoai2, 1, 17000,
        'Trần Thị B', '0987654321');
    cuaHang.taoHoaDon(hoaDon2);

    var hoaDon3 = HoaDon('HD-003', DateTime.now(), dienThoai3, 3, 11000,
        'Lê Văn C', '0912345678');
    cuaHang.taoHoaDon(hoaDon3);

    var hoaDon4 = HoaDon('HD-004', DateTime.now(), dienThoai4, 1, 13000,
        'Phạm Minh D', '0909876543');
    cuaHang.taoHoaDon(hoaDon4);

    // Hiển thị danh sách hóa đơn
    print('Danh sách hóa đơn sau khi tạo:');
    cuaHang.hienThiDanhSachHoaDon();

    // Thống kê
    var fromDate = DateTime.now().subtract(Duration(days: 30));
    var toDate = DateTime.now();
    print(
        'Tổng doanh thu trong 30 ngày qua: ${cuaHang.tinhTongDoanhThu(fromDate, toDate)}');
    print(
        'Tổng lợi nhuận trong 30 ngày qua: ${cuaHang.tinhTongLoiNhuan(fromDate, toDate)}');

    // Thống kê top bán chạy
    var topBanChay = cuaHang.thongKeTopBanChay(2);
    print('Top bán chạy:');
    for (var dt in topBanChay) {
      dt.hienThiThongTin();
    }

    // Báo cáo tồn kho
    print('Báo cáo tồn kho:');
    cuaHang.thongKeTonKho();
  } catch (e) {
    print('Lỗi: $e');
  }
}
